## Book-Hub

Android-App for students to conveniently find buyers for their used books. Students will be able to offer their used books for sale at their own prices. 
Technonlogies Used:  
- Java 
- Android-Studio 
- Firebase  
- whatsapp API
- Google pay API


## Screenshots

##### Home Screen  
<img src="/Screenshots/a11.jpeg" width="300" height="600" /> 

##### Login/Signup  
<img src="/Screenshots/a2.jpeg" width="300" height="600" />  

##### Adding Details  
<img src="/Screenshots/a6.jpeg" width="300" height="600" />  

##### List-View  
<img src="/Screenshots/a8.jpeg" width="300" height="600" />  

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.
